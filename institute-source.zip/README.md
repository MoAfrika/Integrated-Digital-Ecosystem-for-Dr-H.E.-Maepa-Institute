# Dr H.E. Maepa Institute
A South African English public website rebuilt from the supplied Next.js Pages Router application. Includes founder profile, ministry testimony, solar training topics, publisher information and WhatsApp enquiries.

## Build and host
Use Node 22. Check out the project, run npm ci and npm run build. Upload the contents of dist/ to the domain's document root, preserving the folders. Serve directory index.html files and use 404.html for missing pages. For development, use npm run dev.

## Editorial sources
- God With Us Royal Assembly’s testimony: https://www.youtube.com/watch?v=-1LydihcXUA
- Public church listing: https://south-africa.worldplaces.me/places-in-boksburg/52071856-god-with-us-global-royal-assembly.html
- SAQA provider listing: https://qspe.saqa.org.za/showQualification.php?id=49009
- Book, photograph, advertised price and publishing contact: owner-supplied poster at public/art/poster.jpg.
- Solar topics: supplied project curriculum. No intake, accreditation or certification promise is published.

## Enquiries
Visitors review and send their message in WhatsApp. The number belongs to Media & Publication. Card processing, accounts and certificate issuance from the prototype have been retired. The site requires no database or secrets.

## Visitor and media pages
The homepage links directly to /church/ for first visits and /watch/ for the church testimony. The video player is loaded only when activated. Service times should be added once the ministry confirms them. The contact desk remains Dr H.E. Maepa Media & Publication.

Hero photograph by Shane Hoving on Unsplash, https://unsplash.com/photos/an-open-bible-on-a-table-in-the-sunlight-SZaxKdLwz6o. Testimony thumbnail and chapter times come from the church's linked YouTube video.
