export const campuses = ["Windmill Park", "Klippoortjie", "Protea Glen"];
export const youthTopic = "Faith Academy Youth Development";
export const schoolTopic = campus => "School admissions – " + campus;
export const enquiry = topic => "/contact?topic=" + encodeURIComponent(topic);
export const solarFacebook = "https://www.facebook.com/p/MMECE-Solar-61584935169490/";
export const organisations = [
  { key: "schools", title: "Faith Academy Christian Schools", label: "Christian education", copy: "Three Gauteng campuses serving families in Windmill Park, Klippoortjie and Protea Glen.", href: "/schools", action: "Explore the campuses" },
  { key: "youth", title: "Faith Academy Youth Development NPO", label: "Youth development", copy: "Practical learning for young people, from working with a computer to organising information in a spreadsheet.", href: "/youth-development", action: "Explore youth development" },
  { key: "solar", title: "MMECE Solar", label: "Renewable energy", copy: "Solar installations, products, maintenance and repairs from the team in Klippoortjie, Boksburg.", href: "/solar", action: "Contact the solar team" },
  { key: "assembly", title: "God With Us Global Royal Assembly", label: "Christian ministry", copy: "The Windmill Park congregation founded by Dr Maepa. Plan a visit or hear a testimony from the church.", href: "/church", action: "Plan a church visit" }
];
