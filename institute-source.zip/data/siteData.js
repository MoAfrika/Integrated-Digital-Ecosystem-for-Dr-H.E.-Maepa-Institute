export const testimony = "https://www.youtube.com/watch?v=-1LydihcXUA";
export const saqa = "https://qspe.saqa.org.za/showQualification.php?id=49009";
export const whatsapp = (message) => "https://wa.me/27723405009?text=" + encodeURIComponent(message);
export const bookEnquiry = whatsapp("Hello Dr H.E. Maepa Media & Publication. I would like a copy of 31 Days Prayer and Fast. Please confirm availability, the price and collection or delivery options.");
export const courses = [
 { slug:"pv-solar-foundations", title:"PV Solar Foundations", description:"Start with the path sunlight takes from a panel to a working appliance.", lessons:["Solar energy principles","Panels, batteries and inverters","System sizing and site checks","Installation safety"] },
 { slug:"solar-sales-design", title:"Solar Sales & Design", description:"Explore how a household’s energy needs become a solar proposal.", lessons:["Understanding the customer’s energy use","Choosing a system size","Preparing a proposal","Explaining costs and savings"] },
 { slug:"pv-business-launch", title:"PV Business Launch", description:"Explore what it takes to organise a solar service from a first enquiry to handover.", lessons:["Defining a service","Planning delivery","Working with partners","Checking the quality of work"] }
];
