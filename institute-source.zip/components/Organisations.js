import Link from "next/link";
import { organisations } from "../data/organisations";

export function OrganisationLogo({name}) {
  const organisation = organisations.find(item => item.key === name);
  return <img className="orgLogo" src={"/organisations/" + name + ".webp"} alt={organisation.title + " logo"} width="150" height="128" />;
}

export function OrganisationDirectory() {
  return <section className="directory" id="organisations"><div className="wrap">
    <div className="kicker">The organisations</div>
    <h2>Explore Dr Maepa’s work</h2>
    <div className="orgGrid">{organisations.map(item =>
      <article key={item.key} className={"orgCard org-" + item.key}>
        <div className="logoPanel"><OrganisationLogo name={item.key}/></div>
        <div className="orgText"><small>{item.label}</small><h3>{item.title}</h3><p>{item.copy}</p><Link href={item.href}>{item.action}</Link></div>
      </article>
    )}</div>
  </div></section>;
}
