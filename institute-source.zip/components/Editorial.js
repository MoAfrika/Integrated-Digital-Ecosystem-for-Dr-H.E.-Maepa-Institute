import Head from "next/head";
import Link from "next/link";
import {BookOpen,Church,GraduationCap,Feather,Sun} from "lucide-react";
export function Meta({title,desc}){return <Head><title>{title} | Dr H.E. Maepa Institute</title><meta name="description" content={desc}/><meta property="og:title" content={title+" | Dr H.E. Maepa Institute"}/><meta property="og:description" content={desc}/></Head>}
export function BookArt(){return <figure className="bookArt"><div className="artRings" aria-hidden="true"/><div className="corner tl"/><div className="corner tr"/><div className="corner bl"/><div className="corner br"/><p>DR H.E. MAEPA <b>✦</b> PUBLICATIONS</p><div className="cover"><img src="/art/book.webp" alt="Cover of 31 Days Prayer and Fast with 24 Hours Prayer Watch"/></div><figcaption><span/> THE PRAYER COLLECTION <span/></figcaption></figure>}
export const paths=[
 {url:"/church",name:"Ministry",text:"Meet God With Us Royal Assembly in Windmill Park and hear a testimony from the church.",link:"Explore the ministry",icon:Church},
 {url:"/academy",name:"Training",text:"Explore leadership and practical skills, and find the right questions to ask before enrolling.",link:"Explore training",icon:GraduationCap},
 {url:"/shop",name:"Publications",text:"Discover Dr Maepa’s writing on prayer and find a guide for your next church prayer watch.",link:"Browse publications",icon:BookOpen}
];
export function Cards({items=paths}){return <div className="cards">{items.map(({url,name,text,link,icon:Icon=Feather})=><article className="card" key={name}><span className="icon"><Icon size={27} strokeWidth={1.35}/></span><h3>{name}</h3><p>{text}</p><Link href={url}>{link}</Link></article>)}</div>}
export function Page({label,title,desc,children}){return <><Meta title={title} desc={desc}/><section className="innerHero"><div className="wrap"><div className="kicker">{label}</div><h1>{title}</h1><p>{desc}</p></div></section><div className="wrap bodyArea">{children}</div></>}
