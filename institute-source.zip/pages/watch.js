import Link from "next/link";
import { useState } from "react";
import { Play } from "lucide-react";
import { Page } from "../components/Editorial";
import { testimony } from "../data/siteData";

const chapters = [[15, "Pastor Gavin’s background"], [70, "Meeting Dr Maepa"], [205, "Lessons from the encounter"]];
export default function Watch() {
  const [playing,setPlaying] = useState(false);
  return <Page label="Watch · God With Us Royal Assembly" title="From encounter to inspiration" desc="Pastor Gavin Fasasie shares how meeting Dr H.E. Maepa shaped his ministry. A testimony from God With Us Royal Assembly.">
    <div className="watchLayout">
      <article>
        <div className="film">
          {playing ? <iframe title="Pastor Gavin Fasasie’s testimony" src="https://www.youtube-nocookie.com/embed/-1LydihcXUA?autoplay=1" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen/> :
            <button onClick={()=>setPlaying(true)} className="filmPlay"><span className="playCircle"><Play fill="currentColor" size={26}/></span><strong>Play testimony</strong><small>Loads the YouTube player</small></button>}
        </div>
        <p><a href={testimony}>Watch directly on YouTube</a></p>
      </article>
      <aside><div className="kicker">In this testimony</div><h2>Choose a chapter</h2><ul className="chapterList">{chapters.map(([seconds,title])=><li key={seconds}><a href={testimony+"&t="+seconds+"s"}><time>{Math.floor(seconds/60)}:{String(seconds%60).padStart(2,"0")}</time>{title}</a></li>)}</ul><p>Chapter links open on YouTube.</p></aside>
    </div>
    <div className="watchNext"><h2>Meet the community in person</h2><p>Find directions and ask about the next gathering in Windmill Park.</p><Link className="btn" href="/church">Plan a visit</Link></div>
  </Page>;
}
