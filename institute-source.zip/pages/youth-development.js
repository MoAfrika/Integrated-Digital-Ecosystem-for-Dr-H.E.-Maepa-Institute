import Link from "next/link";
import { Page } from "../components/Editorial";
import { OrganisationLogo } from "../components/Organisations";
import { enquiry, youthTopic } from "../data/organisations";

export default function YouthDevelopment() {
  return <Page label="Community education" title="Faith Academy Youth Development NPO" desc="The youth development organisation in Dr Maepa’s network helps young people gain confidence using practical skills. Digital literacy is one place that work begins.">
    <div className="orgIntro"><OrganisationLogo name="youth"/><div><h2>From a first click to a working spreadsheet</h2><p>In beginner computer classes, learners work together to enter figures, use formulas and explain what their answers mean. Building a presentation gives them another way to practise the same skill: turning information into something they can share.</p></div></div>
    <div className="split"><article><h2>For prospective learners</h2><p>Tell the team what you would like to learn and how comfortable you are using a computer. Ask which programme is available, where the class meets and what you need to bring.</p><Link className="btn" href={enquiry(youthTopic)}>Ask about learning opportunities</Link></article><aside><h3>For community partners</h3><p>Representing a youth group, school or employer? Share your group size, location and the skills your learners need.</p><Link href={enquiry("Youth development partnership")}>Discuss a partnership</Link></aside></div>
  </Page>;
}
