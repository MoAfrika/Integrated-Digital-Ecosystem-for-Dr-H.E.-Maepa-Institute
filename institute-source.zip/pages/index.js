import Link from "next/link";
import { Play } from "lucide-react";
import { OrganisationDirectory } from "../components/Organisations";
import { Meta } from "../components/Editorial";

export default function Home() {
  return <>
    <Meta title="Dr Maepa’s work in Gauteng" desc="Meet Dr H.E. Maepa and explore Faith Academy Christian Schools, youth development, MMECE Solar, church ministry and publications." />
    <section className="welcome">
      <picture className="welcomeImage">
        <source media="(max-width: 680px)" srcSet="/art/scripture-small.webp" />
        <img src="/art/scripture.webp" alt="" fetchPriority="high" />
      </picture>
      <div className="welcomeShade" />
      <div className="wrap welcomeText">
        <div className="kicker">Ministry · Education · Enterprise</div>
        <h1>Dr H.E.<br/><em>Maepa</em></h1>
        <p>From a congregation in Windmill Park to three Christian school campuses, a youth development NPO and a solar business, discover the people and places at the heart of Dr Maepa’s work.</p>
        <div className="actions">
          <Link className="btn sunlight" href="/about">Meet Dr Maepa</Link>
          <Link className="btn glass" href="#organisations">Explore the organisations</Link>
        </div>
      </div>
    </section>
    <OrganisationDirectory/>
    <section className="wrap storySpread">
      <div className="storyCopy"><div className="kicker">From the congregation</div>
        <h2>The meeting that shaped a ministry</h2>
        <p>Pastor Gavin Fasasie remembers his first encounter with Dr Maepa and the lessons he carried into his own ministry.</p>
        <Link href="/watch" className="btn"><Play size={16}/> Watch Gavin’s story</Link>
      </div>
      <div className="founderNote"><img src="/art/portrait.webp" width="90" height="122" alt="Dr H.E. Maepa"/><div><div className="kicker">Our founder</div><h3>Dr H.E. Maepa</h3><p>Minister, school owner, author and publisher in Gauteng.</p><Link href="/about">Meet Dr Maepa</Link></div></div>
    </section>
    <section className="publicationFeature"><div className="wrap bookSpread">
      <div className="bookMount"><img loading="lazy" width="186" height="283" src="/art/book.webp" alt="Cover of 31 Days Prayer and Fast"/></div>
      <div><div className="kicker">Books &amp; publications</div><h2>31 Days Prayer and Fast</h2><p>A guide for households and congregations taking their place in a 24-hour prayer watch.</p><Link className="btn" href="/shop">Explore the prayer guide</Link></div>
    </div></section>
  </>;
}
