import Link from "next/link";
import { Play } from "lucide-react";
import { OrganisationDirectory } from "../components/Organisations";
import { Meta } from "../components/Editorial";

export default function Home() {
  return <>
    <Meta title="Renewable energy, education and ministry" desc="Explore Dr H.E. Maepa’s solar PV training, MMECE Solar installations, Faith Academy schools and ministry in South Africa." />
    <section className="welcome">
      <div className="wrap energyHero">
        <div className="welcomeText">
          <div className="kicker">Renewable energy · Education · Ministry</div>
          <h1>Dr H.E.<br/><em>Maepa</em></h1>
          <p>For a young person in Windmill Park, the route into renewable energy can begin with a rooftop solar panel. Dr Maepa’s work connects that opportunity with a wider commitment to education, enterprise and faith.</p>
          <div className="actions"><Link className="btn sunlight" href="/training/pv">Explore his solar training work</Link><Link className="btn glass" href="/about">Meet Dr Maepa</Link></div>
        </div>
        <figure className="heroPortrait"><img src="/art/maepa-formal-640.webp" srcSet="/art/maepa-formal-400.webp 400w, /art/maepa-formal-640.webp 640w, /art/maepa-formal-955.webp 955w" sizes="(max-width: 720px) 100vw, (max-width: 1350px) 45vw, 600px" width="955" height="960" alt="Dr H.E. Maepa wearing a gold bow tie and floral dinner jacket" loading="eager" fetchPriority="high"/></figure>
      </div>
    </section>
    <section className="impactBand"><div className="wrap"><div className="impactPanel"><div className="kicker">Solar PV training</div><strong>5,000+</strong><p>Young men and women trained in renewable energy through Dr Maepa’s work, according to the Institute’s team.</p><div className="reach">The Vaal · North West · Windmill Park, Boksburg</div></div></div></section>
    <OrganisationDirectory/>
    <section className="wrap storySpread">
      <div className="storyCopy"><div className="kicker">From the congregation</div>
        <h2>The meeting that shaped a ministry</h2>
        <p>Pastor Gavin Fasasie remembers his first encounter with Dr Maepa and the lessons he carried into his own ministry.</p>
        <Link href="/watch" className="btn"><Play size={16}/> Watch Gavin’s story</Link>
      </div>
      <div className="founderNote"><img src="/art/portrait.webp" width="90" height="122" alt="Dr H.E. Maepa"/><div><div className="kicker">Our founder</div><h3>Dr H.E. Maepa</h3><p>Renewable-energy educator, school owner, minister and author.</p><Link href="/about">Meet Dr Maepa</Link></div></div>
    </section>
    <section className="publicationFeature"><div className="wrap bookSpread">
      <div className="bookMount"><img loading="lazy" width="186" height="283" src="/art/book.webp" alt="Cover of 31 Days Prayer and Fast"/></div>
      <div><div className="kicker">Books &amp; publications</div><h2>31 Days Prayer and Fast</h2><p>A guide for households and congregations taking their place in a 24-hour prayer watch.</p><Link className="btn" href="/shop">Explore the prayer guide</Link></div>
    </div></section>
  </>;
}
