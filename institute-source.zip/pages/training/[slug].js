import Link from "next/link";
import {Page} from "../../components/Editorial";
import {courses} from "../../data/siteData";
export const getStaticPaths=()=>({paths:courses.map(c=>({params:{slug:c.slug}})),fallback:false});
export const getStaticProps=({params})=>({props:{course:courses.find(c=>c.slug===params.slug)}});
export default function Course({course}){return <Page label="Renewable energy" title={course.title} desc={course.description}><div className="split"><article><h2>Learning topics</h2><ul className="topics">{course.lessons.map(x=><li key={x}>{x}</li>)}</ul></article><aside><h3>Plan your training</h3><p>Ask the team to confirm availability, prerequisites, assessment and the next intake for your group.</p><Link className="btn" href={"/contact?topic="+encodeURIComponent(course.title)}>Enquire about this topic</Link></aside></div></Page>}
