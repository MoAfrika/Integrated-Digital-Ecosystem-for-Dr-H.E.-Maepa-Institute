import Link from "next/link";
import { Sun } from "lucide-react";
import { Page, Cards } from "../../components/Editorial";
import { courses } from "../../data/siteData";

export default function Training() {
  return <Page label="Renewable energy · Skills development" title="Training a generation in solar PV" desc="The Institute’s team reports that Dr H.E. Maepa’s renewable-energy work has trained more than 5,000 young men and women, including learners from the Vaal, North West and Windmill Park in Boksburg.">
    <div className="split"><article>
      <h2>From the classroom to the rooftop</h2>
      <p>In June 2019, Dr Maepa addressed interns in Ekurhuleni about the work they could expect in the field. He described rooftop photovoltaic installation alongside energy management and metering. His plan was for interns to visit working sites and take part in the work themselves. He also identified schools and companies as places where interns could gain experience.</p>
      <p>That distinction matters on a roof. A drawing can tell a learner where panels should sit. A site visit reveals what the drawing might miss, from a tree that casts afternoon shade to the space an installer needs to maintain the array.</p>
      <a href="https://anyflip.com/ptrf/axju/basic/">Read the June 2019 Khula report</a>
      <h2>A voice in South Africa’s solar industry</h2>
      <p>The Solar Show Africa speaker list identified Dr Emmanuel Maepa as the Institute’s Director of Renewable Energy. In 2026, the South African Photovoltaic Industry Association named the Institute among its nominees for the Empowerment Through Skills Award, which recognises work to develop people across the solar sector.</p>
      <p><a href="https://greeneconomy.media/the-solar-show-africa-speaker-list/">Solar Show Africa speaker list</a> · <a href="https://www.linkedin.com/posts/naazia-hassan-65544321_so-proud-of-rhino-energy-solutions-for-being-activity-7475982272882548736-_w1k">SAPVIA nomination announcement</a></p>
    </article><aside><h3>What is solar PV?</h3><p>Photovoltaic panels turn sunlight into electricity. An inverter converts the panels’ direct current into the alternating current used by most appliances. A battery, where included, stores energy for use later.</p><h3>Enquire about training</h3><p>Individuals, schools and community partners can ask about upcoming intakes, supervised practical work, assessment, fees and venues. Include your town and whether you are enquiring for yourself or a group.</p><Link className="btn" href="/contact?topic=Solar%20PV%20training">Ask about solar PV training</Link></aside></div>
    <section className="watchNext"><h2>Three ways into solar work</h2><p>A solar project involves several kinds of work. Explore the technical foundations, the choices behind a quotation and the skills needed to deliver a service.</p>
      <Cards items={courses.map(c => ({url:"/training/"+c.slug,name:c.title,text:c.description,link:"View learning topics",icon:Sun}))}/>
    </section><p>For an installation, product or repair, <Link href="/solar">speak to MMECE Solar in Boksburg</Link>.</p>
  </Page>;
}
