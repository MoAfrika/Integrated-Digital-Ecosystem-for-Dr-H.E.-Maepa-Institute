import {Page,Cards} from "../../components/Editorial";
import Link from "next/link";
import {courses} from "../../data/siteData";
import {Sun} from "lucide-react";
export default function Training(){return <Page label="Training" title="Solar learning pathways" desc="Explore three areas of photovoltaic training. Ask about current delivery, fees and entry requirements before making an enrolment decision."><Cards items={courses.map(c=>({url:"/training/"+c.slug,name:c.title,text:c.description,link:"View learning topics",icon:Sun}))}/><p>Looking for a quote or a repair? <Link href="/solar">Contact MMECE Solar</Link>.</p></Page>}
