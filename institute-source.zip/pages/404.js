import Link from "next/link";
import {Page} from "../components/Editorial";
export default function Missing(){return <Page label="Page unavailable" title="Find your way back" desc="This address may belong to an earlier version of the Institute website."><Link className="btn" href="/">Return to the homepage</Link></Page>}
