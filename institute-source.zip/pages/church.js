import Link from "next/link";
import { MapPin, MessageCircle, Play } from "lucide-react";
import { OrganisationLogo } from "../components/Organisations";
import { Page } from "../components/Editorial";

const directions = "https://www.google.com/maps/dir/?api=1&destination=" + encodeURIComponent("De Waal and Hewitt Drive, Windmill Park, Boksburg, South Africa");
const visitContact = "/contact?topic=Planning+a+visit";

export default function Church() {
  return <Page label="Plan a visit" title="Worship in Windmill Park" desc="Visiting God With Us Global Royal Assembly for the first time? Find the church in Boksburg and check the details for the gathering you’d like to attend.">
    <div className="split visitGrid">
      <article><OrganisationLogo name="assembly"/><div className="kicker">Getting here</div><h2>God With Us Global Royal Assembly</h2>
        <address>Corner of De Waal and Hewitt Drive<br/>Windmill Park, Boksburg<br/>Gauteng, South Africa</address>
        <a className="btn" href={directions}><MapPin size={18}/> Get directions</a>
      </article>
      <aside><div className="kicker">Before you leave</div><h3>Confirm the service time</h3><p>Tell the team which date you plan to visit. The publishing desk can direct you to the church for the gathering time and arrival details.</p>
        <Link href={visitContact} className="btn"><MessageCircle size={18}/> Ask about a visit</Link>
      </aside>
    </div>
    <section className="visitQuestions"><h2>First-visit questions</h2>
      <details><summary>Who leads the church?</summary><p>Dr H.E. Maepa founded God With Us Global Royal Assembly. <Link href="/about">Read about Dr Maepa.</Link></p></details>
      <details><summary>Can I get to know the church online?</summary><p>Hear Pastor Gavin Fasasie tell the story of meeting Dr Maepa in a testimony published by the church. <Link href="/watch">Watch the testimony.</Link></p></details>
      <details><summary>Who can help with parking or accessibility?</summary><p>Ask to speak to the church team before travelling so they can confirm arrangements for your visit. <Link href={visitContact}>Ask a visitor question.</Link></p></details>
    </section>
  </Page>;
}
