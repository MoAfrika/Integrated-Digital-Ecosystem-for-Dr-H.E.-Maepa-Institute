import Link from "next/link";
import { Page } from "../components/Editorial";
import { saqa } from "../data/siteData";

export default function About() {
  return <Page label="Profile" title="Dr H.E. Maepa" desc="Minister, school owner, author and publisher whose work in Gauteng spans Christian education, youth development and renewable energy.">
    <div className="split"><article>
      <h2>Education across three communities</h2><p>Dr Maepa owns Faith Academy Christian Schools across Windmill Park, Klippoortjie and Protea Glen. The schools bring his work into the daily lives of families choosing a Christian education for their children.</p><Link href="/schools">Meet the three campuses</Link>
      <h2>Learning beyond school</h2><p>Faith Academy Youth Development NPO extends that educational work to young people building practical skills. In a computer class, that can mean making a first presentation or using a spreadsheet to answer a question independently.</p><Link href="/youth-development">Explore youth development</Link>
      <h2>Renewable energy in Boksburg</h2><p>His work also reaches households and businesses through MMECE Solar in Klippoortjie. Dr Maepa and Riaan are the listed contacts for installations, products, maintenance and repairs.</p><Link href="/solar">Meet the solar team</Link>
      <h2>From the pulpit to the page</h2><p>Dr Maepa founded God With Us Global Royal Assembly in Windmill Park. His writing carries that ministry into homes and congregations. In <i>31 Days Prayer and Fast</i>, he guides readers through a month of prayer and a 24-hour prayer watch.</p><Link href="/shop">Explore his prayer guide</Link>
    </article><aside><img className="profile" src="/art/portrait.webp" alt="Dr H.E. Maepa"/><h3>The Institute</h3><p>Dr H E Maepa Institute (Pty) Ltd appears in South African Qualifications Authority records. Ask about a specific programme, its current status and entry requirements.</p><a href={saqa}>View the SAQA record</a><p><Link href="/academy">Explore Institute training</Link></p><p><Link href="/watch">Hear Pastor Gavin Fasasie’s testimony</Link></p></aside></div>
  </Page>;
}
