import Link from "next/link";
import { Page } from "../components/Editorial";
import { OrganisationLogo } from "../components/Organisations";
import { campuses, enquiry, schoolTopic } from "../data/organisations";

export default function Schools() {
  return <Page label="Christian education" title="Faith Academy Christian Schools" desc="Dr H.E. Maepa owns all three Faith Academy Christian Schools campuses in Gauteng. Families can begin with the campus closest to home.">
    <div className="orgIntro"><OrganisationLogo name="schools"/><div><h2>A school for your family</h2><p>Faith Academy brings Christian faith into the school day alongside academic learning and character development. When choosing a campus, ask about the grades offered, the daily timetable and opportunities for your child to take part in school life.</p></div></div>
    <h2>Choose a campus</h2><div className="cards">{campuses.map(campus => <article className="card" key={campus}><h3>{campus}</h3><p>Ask about grade availability, fees, application documents or a visit to the {campus} campus.</p><Link href={enquiry(schoolTopic(campus))}>Enquire about {campus}</Link></article>)}</div>
  </Page>;
}
