import Link from "next/link";
import { Page } from "../components/Editorial";
import { OrganisationLogo } from "../components/Organisations";
import { solarFacebook } from "../data/organisations";

export default function Solar() {
  return <Page label="Renewable energy · Boksburg" title="MMECE Solar" desc="Based in Klippoortjie, Boksburg, MMECE Solar provides solar installations, maintenance, products and repairs. Speak directly to Dr H.E. Maepa or Riaan about your property or existing system.">
    <div className="orgIntro"><OrganisationLogo name="solar"/><div><h2>Planning an installation?</h2><p>Tell the team whether the property is a home or business, where it is, and what needs to keep running during an outage. A list of appliances and the backup time you need gives the team a starting point for a quote.</p></div></div>
    <div className="split"><article><h2>What should an installation quote cover?</h2><p>Start with a typical day on the property. A shop may use most of its power while the sun is up. A household may need lights, refrigeration and internet into the evening. Those patterns help the team discuss how much power the inverter must supply at once and how much energy a battery would need to store.</p>
      <h3>Panels, roof space and shade</h3><p>When arranging a site assessment, mention the roof type and any nearby trees or buildings. Ask where the panels could go, how seasonal shade affects expected output and where the inverter and any batteries would be installed.</p>
      <h3>Handover and aftercare</h3><p>Ask for the proposed equipment models, an itemised price, warranty terms and an explanation of which circuits will have backup power. At handover, ask how to read the system display, where to find the documentation and whom to call if performance changes.</p>
      <h2>Already have a system?</h2><p>For maintenance or repairs, describe what has changed and when you first noticed it. If you are looking for a product, have the name or model of your existing equipment ready when you call.</p><a href={solarFacebook}>Visit MMECE Solar on Facebook</a></article><aside><h3>Call MMECE Solar</h3><p>Installations, product enquiries and service requests</p><div className="solarCalls"><a href="tel:+27834529528">Dr H.E. Maepa · 083 452 9528</a><a href="tel:+27612439862">Riaan · 061 243 9862</a></div></aside></div>
    <div className="watchNext"><h3>Interested in learning about solar?</h3><p>Read about Dr Maepa’s work with young people across the Vaal, North West and Windmill Park, including his plans for supervised experience on working sites.</p><Link href="/training/pv">Explore solar training</Link></div>
  </Page>;
}
