module.exports = { output: "export", trailingSlash: true, reactStrictMode: true, experimental: { cpus: 1 } };
