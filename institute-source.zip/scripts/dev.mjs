import {spawn} from "node:child_process";
const args = process.argv.slice(2).filter(x => x !== "--strictPort").map(x => x === "--host" ? "--hostname" : x);
const child = spawn(process.execPath, ["node_modules/next/dist/bin/next", "dev", "--webpack", ...args], {stdio:"inherit"});
child.on("exit", code => process.exit(code ?? 1));
